/*
 * mm-explicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 * @id : 201302482 
 * @name : Jung yun su
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif
static char* heap_listp=0;
static char* free_listp=0;
/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8
#define HDRSIZE 4
#define FTRSIZE 4
#define WSIZE 4
#define DSIZE 8
#define CHUNKSIZE (1<<12)
#define OVERHEAD 8
#define MAX(x,y) ((x) > (y) ? (x) : (y))
#define MIN(x,y) ((x) < (y) ? (x) : (y))
#define PACK(size,alloc) ( ((size) | (alloc)))
#define GET(p) (*(unsigned *)(p))
#define PUT(p,val)	(*(unsigned *)(p) = (val))
#define GET8(p)	(*(unsigned long *)(p))
#define PUT8(p,val)	(*(unsigned long *)(p) = (unsigned long)(val))
#define GET_SIZE(p)	(GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)
#define HDRP(bp)	((void *)(bp) -WSIZE)
#define FTRP(bp)	((void *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
#define NEXT_BLKP(bp)	((void *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp)	((void *)(bp) - GET_SIZE(HDRP(bp) - WSIZE))
#define NEXT_FREEP(bp)	(*(void **)(bp+DSIZE))
#define PREV_FREEP(bp)	(*(void **)(bp))
static void *extend_heap(size_t words);
static void *find_fit(size_t asize);
static void place(void *bp,size_t asize);
void *coalesce(void* bp);
static void removeBlock(void *bp);
static void insertAtFront(void *bp);
/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)

/*
 * Initialize: return -1 on error, 0 on success.
 */
int mm_init(void) {
	if((heap_listp = mem_sbrk(6*DSIZE)) == NULL)
		return -1;
	PUT(heap_listp,0);
	PUT(heap_listp+WSIZE,PACK(24,1));
	PUT(heap_listp+DSIZE,0);
	PUT(heap_listp+DSIZE+WSIZE,0);
	PUT(heap_listp+24,PACK(24,1));
	PUT(heap_listp+WSIZE+24,PACK(0,1));
	free_listp = heap_listp+DSIZE;
	if(extend_heap(CHUNKSIZE/WSIZE) == NULL)
		return -1;
	return 0;
}
static void *extend_heap(size_t words){
	char *bp;
	size_t size;

	size = (words%2) ? (words+1)*WSIZE : words*WSIZE;
	if(size < 3*DSIZE)
		size = 3*DSIZE;
	if((long)(bp = mem_sbrk(size))==-1)
		return NULL;
	PUT(HDRP(bp),PACK(size,0));
	PUT(FTRP(bp),PACK(size,0));
	PUT(HDRP(NEXT_BLKP(bp)),PACK(0,1));
	return coalesce(bp);
}
static void *find_fit(size_t asize){

	void *bp;
	for(bp=free_listp;GET_ALLOC(HDRP(bp))==0;bp=NEXT_FREEP(bp)){

		if(asize <= (size_t)GET_SIZE(HDRP(bp)))
			return bp;
	}
	return NULL;
}
static void place(void *bp,size_t asize){
	size_t csize = GET_SIZE(HDRP(bp));
	if((csize-asize)>=3*DSIZE){
		PUT(HDRP(bp),PACK(asize,1));
		PUT(FTRP(bp),PACK(asize,1));
		removeBlock(bp);
		bp = NEXT_BLKP(bp);
		PUT(HDRP(bp),PACK(csize-asize,0));
		PUT(FTRP(bp),PACK(csize-asize,0));
		coalesce(bp);
	}
	else{
		PUT(HDRP(bp),PACK(csize,1));
		PUT(FTRP(bp),PACK(csize,1));
		removeBlock(bp);
		bp=NEXT_BLKP(bp);
	}

}
void *coalesce(void *bp){
	size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp))) || PREV_BLKP(bp)==bp;
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	size_t size = GET_SIZE(HDRP(bp));
	if(prev_alloc && !next_alloc){
		size+=GET_SIZE(HDRP(NEXT_BLKP(bp)));
		removeBlock(NEXT_BLKP(bp));
		PUT(HDRP(bp),PACK(size,0));
		PUT(FTRP(bp),PACK(size,0));
	}
	else if(!prev_alloc && next_alloc){
		size +=GET_SIZE(HDRP(PREV_BLKP(bp)));
		bp = PREV_BLKP(bp);
		removeBlock(bp);
		PUT(HDRP(bp),PACK(size,0));
		PUT(FTRP(bp),PACK(size,0));
	}
	else if(!prev_alloc && !next_alloc)
	{
		size+=GET_SIZE(HDRP(PREV_BLKP(bp)))+GET_SIZE(HDRP(NEXT_BLKP(bp)));
		removeBlock(PREV_BLKP(bp));
		removeBlock(NEXT_BLKP(bp));
		bp = PREV_BLKP(bp);
		PUT(HDRP(bp),PACK(size,0));
		PUT(FTRP(bp),PACK(size,0));
	}
	insertAtFront(bp);
	return bp;
}
/*
 * malloc
 */
void *malloc (size_t size) {
    char *bp;
	unsigned asize;
	unsigned extendsize;
	if(size <= 0)
		return NULL;
	asize = MAX(ALIGN(size)+DSIZE,3*DSIZE);
	if((bp = find_fit(asize)) !=NULL){
		place(bp,asize);
		return bp;
	}
	extendsize = MAX(asize,CHUNKSIZE);
	if((bp = extend_heap(extendsize/WSIZE)) ==NULL)
		return NULL;
	place(bp,asize);
	return bp;
}
static void removeBlock(void *bp){
	if(PREV_FREEP(bp))
		NEXT_FREEP(PREV_FREEP(bp)) = NEXT_FREEP(bp);
	else
		free_listp = NEXT_FREEP(bp);
	PREV_FREEP(NEXT_FREEP(bp)) = PREV_FREEP(bp);


}
static void insertAtFront(void *bp){
	NEXT_FREEP(bp) = free_listp;
	PREV_FREEP(free_listp) = bp;
	PREV_FREEP(bp) = NULL;
	free_listp = bp;

}
/*
 * free
 */
void free (void *ptr) {
    if(!ptr)
		return ;
	size_t size = GET_SIZE(HDRP(ptr));
	PUT(HDRP(ptr),PACK(size,0));
	PUT(FTRP(ptr),PACK(size,0));
	coalesce(ptr);
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *oldptr, size_t size) {
    size_t oldsize;
	void *newptr;
	size_t asize=MAX(ALIGN(size)+DSIZE,24);
	if(size<=0){
		free(oldptr);
		return 0;
	}
	if(oldptr == NULL)
		return malloc(size);
	oldsize = GET_SIZE(HDRP(oldptr));
	if(asize ==oldsize)
		return oldptr;
	if(asize <= oldsize){
		size = asize;
		if(oldsize - size <=24)
			return oldptr;
		PUT(HDRP(oldptr),PACK(size,1));
		PUT(FTRP(oldptr),PACK(size,1));
		PUT(HDRP(NEXT_BLKP(oldptr)),PACK(oldsize-size,1));
		free(NEXT_BLKP(oldptr));
		return oldptr;
	}
	newptr = malloc(size);

	if(!newptr)
		return 0;
	if(size<oldsize)
		oldsize =size;
	memcpy(newptr,oldptr,oldsize);
	free(oldptr);
	return newptr;



}

/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
    return NULL;
}


/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}
